"""Local and SSH/SCP orchestration for portable distributed plans.

Connection settings remain local. Deployments snapshot node assignments and keep
their own state, so a controller can reconnect without launching duplicate tasks.
Fetching preserves results separately; the existing collect command publishes them.
"""
import contextlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

import openriak_distributed as distributed
import openriak_locks


TERMINAL = {'complete', 'failed', 'interrupted'}


def default_nodes_file():
    root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config')))
    return root / 'openriak-docker' / 'nodes.json'


def configure_parsers(subcommands, tool):
    add = subcommands.add_parser('add-node', help='Save a named local or SSH worker')
    add.add_argument('name')
    add.add_argument('host', nargs='?', help='SSH destination: user@IPv4-address or user@hostname; omit with --local')
    add.add_argument('--local', action='store_true', help='Run on this machine without SSH or an SSH key')
    add.add_argument('--workdir', required=True, help='Working folder: absolute path or ~/path')
    add.add_argument('--ssh-key', type=Path, help='Local private key path; required for SSH nodes')
    add.add_argument('--port', type=int, help='SSH port (default: 22)')
    add.add_argument('--replace', action='store_true', help='Update an existing named node')
    add.add_argument('--nodes-file', type=Path, default=default_nodes_file())
    listing = subcommands.add_parser('list-nodes', help='List saved SSH node settings')
    listing.add_argument('--nodes-file', type=Path, default=default_nodes_file())
    check = subcommands.add_parser('check-nodes', help='Check local prerequisites or SSH login and exit')
    start = subcommands.add_parser('run', aliases=['start'], help='Execute the plan on all selected workers; every worker runs with nohup')
    for parser in (check, start):
        parser.add_argument('--nodes-file', type=Path, default=default_nodes_file())
        parser.add_argument('--node', action='append', help='Saved node name; repeat in worker-number order (default: all, sorted by name)')
    start.add_argument('--plan', type=Path, required=True)
    start.add_argument('--deployment', type=Path, help='Controller state file (default: PLAN.remote.json); repeat run to resume a partial launch')
    start.add_argument('--output', '--results-dir', dest='results_dir', type=Path,
                       help='Local results root (default: PLAN.results/); each worker uses a subdirectory named after its node')
    monitor = subcommands.add_parser('monitor', help='Check local/SSH worker processes and fetch finished results')
    monitor.add_argument('--watch', action='store_true', help='Poll until every worker has stopped and results are fetched')
    monitor.add_argument('--poll-interval', type=int, default=15)
    monitor.add_argument('--nohup', action='store_true', help='Monitor/fetch in the background; requires --watch')
    fetch = subcommands.add_parser('fetch', help='Copy results from stopped local/SSH workers, including diagnostics')
    logs = subcommands.add_parser('logs', help='Stream one worker log using local or SSH tail -f')
    for parser in (monitor, fetch, logs):
        parser.add_argument('--deployment', type=Path, required=True)
    logs.add_argument('--node', required=True, help='One node name from the deployment')
    logs.add_argument('--lines', type=int, default=100)
    logs.add_argument('--no-follow', action='store_true', help='Print recent lines and exit')
    for parser in (check, start, monitor, fetch, logs):
        parser.add_argument('--connect-timeout', type=int, default=10, help='Seconds allowed to establish SSH')
        parser.add_argument('--timeout', type=int, default=30 if parser is check else tool.DEFAULT_TIMEOUT_SECONDS,
                            help='Seconds per SSH control operation or SCP transfer (continuous log streaming is unlimited)')


def is_local(node):
    return node.get('transport', 'ssh') == 'local'


def validate_node(tool, name, node, *, check_key=False):
    if not isinstance(node, dict):
        raise tool.DockerToolError(f'Node settings must be an object: {name}')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name):
        raise tool.DockerToolError('Node name must contain only letters, numbers, dots, underscores and hyphens')
    if node.get('transport', 'ssh') not in ('local', 'ssh'):
        raise tool.DockerToolError('Node transport must be local or ssh')
    if is_local(node):
        if any(node.get(field) is not None for field in ('host', 'port', 'ssh_key')):
            raise tool.DockerToolError('Local nodes cannot specify SSH host, port or key')
        folder = node.get('workdir', '')
        if not isinstance(folder, str) or not folder or not Path(folder).expanduser().is_absolute():
            raise tool.DockerToolError('Local workdir must be absolute or start with ~/')
        tool.standalone_output(folder)
        return
    if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*@[A-Za-z0-9][A-Za-z0-9.-]*', node.get('host', '')):
        raise tool.DockerToolError('Use an SSH destination of user@IPv4-address or user@hostname')
    folder = node.get('workdir', '')
    # A restricted remote path works unchanged with both legacy SCP and SFTP SCP.
    if (not re.fullmatch(r'(?:/|~/)[A-Za-z0-9_./-]*', folder)
            or '..' in Path(folder).parts or folder in ('/', '~/')):
        raise tool.DockerToolError('Remote workdir must be a folder under / or ~/; use letters, digits, dots, underscores, hyphens and slashes')
    if not isinstance(node.get('port'), int) or not 1 <= node['port'] <= 65535:
        raise tool.DockerToolError('SSH port must be between 1 and 65535')
    key = Path(node.get('ssh_key', '')).expanduser()
    if not key.is_absolute() or (check_key and not key.is_file()):
        raise tool.DockerToolError(f'SSH key file is missing or not absolute: {key}')


def read_nodes(tool, path):
    data = tool.read_json(path) if path.exists() else {'schema_version': 1, 'nodes': {}}
    if data.get('schema_version') != 1 or not isinstance(data.get('nodes'), dict):
        raise tool.DockerToolError('Unsupported SSH nodes configuration')
    for name, node in data['nodes'].items():
        validate_node(tool, name, node)
    return data


def selected_nodes(tool, options):
    config = read_nodes(tool, options.nodes_file)['nodes']
    names = options.node or sorted(config)
    if not names or len(set(names)) != len(names):
        raise tool.DockerToolError('Select at least one node without duplicate names')
    for name in names:
        if name not in config:
            raise tool.DockerToolError(f'Unknown SSH node: {name}')
        validate_node(tool, name, config[name], check_key=True)
    return [(name, config[name]) for name in names]


def connection(node, options, program):
    return [program, '-i', node['ssh_key'], '-p' if program == 'ssh' else '-P', str(node['port']),
            '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
            '-o', f'ConnectTimeout={options.connect_timeout}', '-o', 'ServerAliveInterval=15',
            '-o', 'ServerAliveCountMax=3']


def ssh_command(node, options, arguments):
    # SSH joins the remote command through the login shell: quote each argument.
    return connection(node, options, 'ssh') + [node['host'], shlex.join(arguments)]


def execute(tool, command, timeout):
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True,
                                text=True, timeout=timeout)
    except subprocess.TimeoutExpired as error:
        raise tool.DockerToolError(f'{command[0]} timed out after {timeout}s; worker builds, if started, keep running') from error
    if result.returncode:
        raise tool.DockerToolError(f'{command[0]} failed ({result.returncode}): {result.stderr.strip()[-2000:]}')
    return result.stdout


def remote_call(tool, node, options, request):
    helper = Path(__file__).with_name('openriak_remote_worker.py')
    command = ([sys.executable, str(helper), json.dumps(request)] if is_local(node) else
               ssh_command(node, options, ['python3', '-c', helper.read_text(), json.dumps(request)]))
    output = execute(tool, command, options.timeout)
    try:
        result = json.loads(output)
    except ValueError as error:
        raise tool.DockerToolError('Worker helper did not return JSON; check Python availability and, for SSH, login-shell output') from error
    if not isinstance(result, dict) or (request['action'] == 'prepare' and not isinstance(result.get('remote_dir'), str)):
        raise tool.DockerToolError('Invalid SSH helper response')
    if request['action'] != 'prepare' and result.get('status') not in TERMINAL | {'staged', 'running', 'unknown'}:
        raise tool.DockerToolError('Invalid worker status from SSH helper')
    return result


def scp(tool, node, options, source, destination, *, recursive=False):
    command = connection(node, options, 'scp') + (['-r'] if recursive else [])
    execute(tool, command + [str(source), str(destination)], options.timeout)


def read_deployment(tool, path):
    data = tool.read_json(path)
    if data.get('schema_version') != 1 or data.get('kind') != 'openriak-ssh-deployment':
        raise tool.DockerToolError('Unsupported SSH deployment')
    identity = {k: v for k, v in data['plan'].items() if k != 'id'}
    if distributed.digest(identity) != data['plan']['id']:
        raise tool.DockerToolError('Deployment plan checksum mismatch')
    if len(data['nodes']) != data['plan']['workers']:
        raise tool.DockerToolError('Deployment assignment count does not match plan')
    for number, node in enumerate(data['nodes'], 1):
        validate_node(tool, node['name'], node)
        if node['worker'] != number:
            raise tool.DockerToolError('Invalid deployment worker assignment')
    return data


def request_for(deployment, node, action):
    return {'action': action, 'plan_id': deployment['plan']['id'],
            'worker': node['worker'], 'remote_dir': node['remote_dir']}


def start(tool, options):
    plan = distributed.load_plan(tool, options.plan)
    distributed.plan_targets(tool, plan)
    path = (options.deployment or options.plan.with_suffix('.remote.json')).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with openriak_locks.lock(tool, path):
        if path.exists():
            deployment = read_deployment(tool, path)
            if deployment['plan']['id'] != plan['id']:
                raise tool.DockerToolError('Deployment belongs to another plan')
            if options.node and options.node != [n['name'] for n in deployment['nodes']]:
                raise tool.DockerToolError('Node assignments cannot change after staging')
            if options.results_dir and options.results_dir.expanduser().resolve() != Path(deployment['results_dir']):
                raise tool.DockerToolError('Result destination cannot change after staging')
        else:
            nodes = selected_nodes(tool, options)
            if len(nodes) != plan['workers']:
                raise tool.DockerToolError(f'Plan needs {plan["workers"]} nodes; selected {len(nodes)}')
            if len({('local',) if is_local(n) else ('ssh', n['host'], n['port']) for _, n in nodes}) != len(nodes):
                raise tool.DockerToolError('Use at most one local worker and one worker per SSH host/port; duplicates share the same Docker builder')
            identifier = tool.run_id()
            results = tool.standalone_output(str(options.results_dir or options.plan.with_suffix('.results')))
            # Node paths must also work with SCP: normalize unusual plan filenames
            # only for the worker-side folder, retaining the original local name.
            plan_folder = re.sub(r'[^A-Za-z0-9_.-]+', '_', options.plan.stem).strip('.') or 'plan'
            deployment = {'schema_version': 1, 'kind': 'openriak-ssh-deployment', 'id': identifier,
                          'created_at': tool.isoformat(), 'plan': plan, 'results_dir': str(results),
                          'nodes': [dict(node, name=name, worker=index, status='pending',
                                         result_subdirectory=name,
                                         remote_dir=node['workdir'].rstrip('/') + f'/openriak-distributed/{plan_folder}/{name}/{identifier}')
                                    for index, (name, node) in enumerate(nodes, 1)]}
            tool.write_json(path, deployment)
        # Keep exactly the same compressed bytes on reconnection after a partial
        # launch; creating a fresh gzip would otherwise change its transfer hash.
        if 'bundle' not in deployment:
            bundle = path.with_suffix('.bundle.tar.gz')
            distributed.write_bundle(tool, plan, options.plan, bundle)
            deployment.update(bundle=str(bundle), bundle_sha256=tool.sha256_file(bundle))
            tool.write_json(path, deployment)
        bundle = Path(deployment['bundle'])
        bundle_hash = deployment['bundle_sha256']
        if tool.sha256_file(bundle) != bundle_hash:
            raise tool.DockerToolError('Deployment source bundle changed; refusing to stage it')
        errors = 0
        for node in deployment['nodes']:
            try:
                # A staged deployment is immutable; status reconnects after a lost response.
                prepared = remote_call(tool, node, options, request_for(deployment, node, 'prepare'))
                remote_dir = prepared['remote_dir']
                if not is_local(node) and not re.fullmatch(r'/[A-Za-z0-9_./-]+', remote_dir):
                    raise tool.DockerToolError('Resolved remote folder is not a safe SCP path')
                node['remote_dir'] = remote_dir
                previous = remote_call(tool, node, options, request_for(deployment, node, 'status'))
                if previous['status'] == 'staged':
                    method = 'a local copy' if is_local(node) else 'SCP'
                    print(f'{tool.log_timestamp()} {node["name"]}: staging worker {node["worker"]} with {method}', flush=True)
                    staged_bundle = f'{remote_dir}/bundle-{bundle_hash}.tar.gz'
                    if is_local(node):
                        execute(tool, ['cp', '--', str(bundle), staged_bundle], options.timeout)
                    else:
                        scp(tool, node, options, bundle, f'{node["host"]}:{staged_bundle}')
                    request = dict(request_for(deployment, node, 'start'), sha256=bundle_hash)
                    previous = remote_call(tool, node, options, request)
                node.update(status=previous['status'], remote=previous)
                node.pop('error', None)
                print(f'{tool.log_timestamp()} {node["name"]}: {node["status"]}; PID {previous.get("pid", "?")}; log {previous.get("log", remote_dir + "/worker.log")}', flush=True)
                collected = Path(deployment['results_dir']) / node.get('result_subdirectory', f'worker-{node["worker"]}')
                print(f'  Worker output: {remote_dir}/results; retrieved output: {collected}', flush=True)
                if previous.get('error'):
                    print(f'  {previous["error"]}', flush=True)
                if node['status'] in ('failed', 'interrupted', 'unknown'):
                    errors += 1
            except (tool.DockerToolError, OSError, ValueError) as error:
                node['error'] = str(error)
                errors += 1
                print(f'{tool.log_timestamp()} {node["name"]}: ERROR: {error}', flush=True)
            finally:
                tool.write_json(path, deployment)
        print(f'Deployment: {path}', flush=True)
        print(f'Monitor and fetch: tools/openriak-docker/openriak-docker distribute monitor --deployment {shlex.quote(str(path))} --watch', flush=True)
        return 1 if errors else 0


def verify_download(tool, deployment, node, root, expected):
    """Check transferred receipts and passed archives before making them visible."""
    if any(p.is_symlink() for p in root.rglob('*')):
        raise tool.DockerToolError('Symlink in transferred results')
    receipt_path = root / 'worker.json'
    if not expected:
        if receipt_path.exists():
            raise tool.DockerToolError('Worker receipt appeared during transfer; recheck remote process')
        return
    receipt = tool.read_json(receipt_path)
    if receipt != expected or (receipt.get('plan_id'), receipt.get('worker')) != (deployment['plan']['id'], node['worker']):
        raise tool.DockerToolError('Transferred worker receipt changed or belongs to another assignment')
    jobs = {j['image_tag']: j for j in deployment['plan']['jobs'] if j['worker'] == node['worker']}
    if receipt['status'] == 'complete' and set(receipt['results']) != set(jobs):
        raise tool.DockerToolError('Completed worker is missing assigned image groups')
    for tag, row in receipt.get('results', {}).items():
        if tag not in jobs:
            raise tool.DockerToolError('Unexpected group in worker receipt')
        if row['status'] != 'passed':
            if receipt['status'] == 'complete':
                raise tool.DockerToolError('Completed worker contains an unapproved group')
            continue
        folder = root / jobs[tag]['targets'][0][0] / tag
        if tool.sha256_file(folder / 'report.json') != row['report_sha256']:
            raise tool.DockerToolError('Transferred approval checksum mismatch')
        report = tool.read_json(folder / 'report.json')
        for artifact in report.get('artifacts', {}).values():
            file = distributed.confined(folder, artifact['filename'])
            if tool.sha256_file(file) != artifact['sha256']:
                raise tool.DockerToolError('Transferred artifact checksum mismatch')
        archive = distributed.confined(folder, report['oci_archive'])
        if tool.sha256_file(archive) != row['archive_sha256']:
            raise tool.DockerToolError('Transferred OCI archive checksum mismatch')


def fetch_node(tool, options, deployment, node, snapshot):
    if snapshot['status'] not in TERMINAL:
        return False
    signature = distributed.digest({'pid': snapshot.get('pid'), 'status': snapshot['status'], 'receipt': snapshot.get('receipt')})
    subdirectory = node.get('result_subdirectory', f'worker-{node["worker"]}')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', subdirectory):
        raise tool.DockerToolError('Invalid worker result subdirectory')
    destination = Path(deployment['results_dir']) / subdirectory
    if node.get('fetched_signature') == signature and destination.is_dir():
        return True
    if destination.exists():
        marker = destination / 'remote-fetch.json'
        if marker.is_file() and tool.read_json(marker) == {'signature': signature, 'deployment': deployment['id']}:
            verify_download(tool, deployment, node, destination, snapshot.get('receipt'))
            node.update(fetched_signature=signature, fetched_at=tool.isoformat(), local_results=str(destination))
            return True
        raise tool.DockerToolError(f'Result destination already exists; preserving it: {destination}')
    destination.parent.mkdir(parents=True, exist_ok=True)
    method = 'a local copy' if is_local(node) else 'SCP'
    print(f'{tool.log_timestamp()} {node["name"]}: fetching {snapshot["status"]} results with {method}', flush=True)
    with tempfile.TemporaryDirectory(prefix='.fetch-', dir=destination.parent) as directory:
        stage = Path(directory)
        if is_local(node):
            execute(tool, ['cp', '-a', '--', node['remote_dir'] + '/results', str(stage / 'results')], options.timeout)
            execute(tool, ['cp', '--', node['remote_dir'] + '/worker.log', str(stage / 'results' / 'remote-worker.log')], options.timeout)
        else:
            scp(tool, node, options, f'{node["host"]}:{node["remote_dir"]}/results', stage, recursive=True)
            scp(tool, node, options, f'{node["host"]}:{node["remote_dir"]}/worker.log', stage / 'results' / 'remote-worker.log')
        after = remote_call(tool, node, options, request_for(deployment, node, 'status'))
        if after['status'] != snapshot['status'] or after.get('pid') != snapshot.get('pid') or after.get('receipt') != snapshot.get('receipt'):
            raise tool.DockerToolError('Remote task changed during transfer; results were not promoted')
        verify_download(tool, deployment, node, stage / 'results', snapshot.get('receipt'))
        tool.write_json(stage / 'results' / 'remote-fetch.json', {'signature': signature, 'deployment': deployment['id']})
        os.replace(stage / 'results', destination)
    node.update(fetched_signature=signature, fetched_at=tool.isoformat(), local_results=str(destination))
    return True


def monitor(tool, options, arguments):
    path = options.deployment.expanduser().resolve()
    deployment = read_deployment(tool, path)
    if getattr(options, 'nohup', False):
        if not options.watch:
            raise tool.DockerToolError('monitor --nohup requires --watch')
        import openriak_background
        options.output = str(path.parent)
        return openriak_background.launch(tool, options, arguments)
    interval = getattr(options, 'poll_interval', 15)
    if interval < 1:
        raise tool.DockerToolError('--poll-interval must be positive')
    watch = getattr(options, 'watch', False)
    while True:
        with openriak_locks.lock(tool, path):
            deployment = read_deployment(tool, path)
            for node in deployment['nodes']:
                try:
                    snapshot = remote_call(tool, node, options, request_for(deployment, node, 'status'))
                    node.update(status=snapshot['status'], remote=snapshot, checked_at=tool.isoformat())
                    node.pop('error', None)
                    print(f'{tool.log_timestamp()} {node["name"]}: {snapshot["status"]}; PID {snapshot.get("pid", "?")}', flush=True)
                    if snapshot.get('error'):
                        print(f'  {snapshot["error"]}', flush=True)
                    fetch_node(tool, options, deployment, node, snapshot)
                except (tool.DockerToolError, OSError, ValueError) as error:
                    node['error'] = str(error)
                    print(f'{tool.log_timestamp()} {node["name"]}: ERROR: {error}', flush=True)
                finally:
                    tool.write_json(path, deployment)
        complete = all(n['status'] in TERMINAL and n.get('fetched_signature') and not n.get('error') for n in deployment['nodes'])
        needs_operator = any(n['status'] in ('unknown', 'staged', 'pending') and not n.get('error') for n in deployment['nodes'])
        if complete or not watch or needs_operator:
            success = all(n['status'] == 'complete' and not n.get('error') for n in deployment['nodes'])
            if complete:
                print(f'All worker results fetched into {deployment["results_dir"]}', flush=True)
                if success:
                    command = ['tools/openriak-docker/openriak-docker', 'distribute', 'collect', '--plan', str(path.with_suffix('.plan.json'))]
                    tool.write_json(path.with_suffix('.plan.json'), deployment['plan'])
                    for node in deployment['nodes']:
                        command.extend(['--results', node['local_results']])
                    print('Preview publication: ' + shlex.join(command + ['--whatif']), flush=True)
            # A one-shot status check succeeds while healthy workers are still running.
            if not watch and options.distributed_command == 'monitor':
                return 1 if any(n.get('error') or n['status'] in ('failed', 'interrupted', 'unknown', 'staged', 'pending') for n in deployment['nodes']) else 0
            return 0 if complete and success else 1
        time.sleep(interval)


def logs(tool, options):
    if options.lines < 0:
        raise tool.DockerToolError('--lines must be nonnegative')
    deployment = read_deployment(tool, options.deployment)
    node = next((n for n in deployment['nodes'] if n['name'] == options.node), None)
    if not node:
        raise tool.DockerToolError(f'Node is not in this deployment: {options.node}')
    arguments = ['tail', '-n', str(options.lines)] + ([] if options.no_follow else ['-f']) + [node['remote_dir'] + '/worker.log']
    command = arguments if is_local(node) else ssh_command(node, options, arguments)
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, timeout=options.timeout if options.no_follow else None)
    except KeyboardInterrupt:
        print('Log viewer stopped; worker builds continue.', flush=True)
        return 130
    except subprocess.TimeoutExpired as error:
        raise tool.DockerToolError(f'Log read timed out after {options.timeout}s') from error
    return result.returncode


def main(tool, options, arguments):
    command = options.distributed_command
    if hasattr(options, 'timeout') and (options.timeout < 1 or options.connect_timeout < 1):
        raise tool.DockerToolError('SSH connection and operation timeouts must be positive')
    if command == 'add-node':
        if options.local:
            if options.host or options.ssh_key or options.port is not None:
                raise tool.DockerToolError('--local cannot be combined with an SSH host, key or port')
            node = {'transport': 'local', 'workdir': options.workdir}
        else:
            if not options.host or not options.ssh_key:
                raise tool.DockerToolError('SSH nodes require user@HOST and --ssh-key; use --local for this machine')
            node = {'transport': 'ssh', 'host': options.host, 'workdir': options.workdir,
                    'port': options.port if options.port is not None else 22, 'ssh_key': str(options.ssh_key.expanduser().resolve())}
        validate_node(tool, options.name, node, check_key=True)
        if options.local:
            node['workdir'] = str(Path(options.workdir).expanduser().resolve())
        path = options.nodes_file.expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        with openriak_locks.lock(tool, path):
            data = read_nodes(tool, path)
            if options.name in data['nodes'] and not options.replace:
                raise tool.DockerToolError('Node already exists; use --replace to update its settings')
            data['nodes'][options.name] = node
            tool.write_json(path, data)
            path.chmod(0o600)
        print(f'Saved node {options.name}: {"local (no SSH)" if options.local else options.host}; settings: {path}')
        return 0
    if command == 'list-nodes':
        for name, node in sorted(read_nodes(tool, options.nodes_file)['nodes'].items()):
            if is_local(node):
                print(f'{name}: local (no SSH); workdir {node["workdir"]}')
            else:
                print(f'{name}: {node["host"]}:{node["port"]}; workdir {node["workdir"]}; key {node["ssh_key"]}')
        return 0
    if command == 'check-nodes':
        failures = 0
        for name, node in selected_nodes(tool, options):
            try:
                if is_local(node):
                    for program in ('nohup', 'ps', 'cp', 'tail'):
                        if not shutil.which(program):
                            raise tool.DockerToolError(f'Local worker requires {program} on PATH')
                    existing = Path(node['workdir']).expanduser()
                    while not existing.exists():
                        existing = existing.parent
                    if not existing.is_dir() or not os.access(existing, os.W_OK | os.X_OK):
                        raise tool.DockerToolError(f'Local workdir is not writable: {existing}')
                    execute(tool, [sys.executable, '-c', 'pass'], options.timeout)
                    print(f'{tool.log_timestamp()} OK {name}: local worker prerequisites checked (no SSH)', flush=True)
                else:
                    execute(tool, ssh_command(node, options, ['true']), options.timeout)
                    print(f'{tool.log_timestamp()} OK {name}: SSH login succeeded and exited')
            except (tool.DockerToolError, OSError) as error:
                failures += 1
                print(f'{tool.log_timestamp()} FAILED {name}: {error}')
        return 1 if failures else 0
    if command in ('run', 'start'):
        return start(tool, options)
    if command == 'logs':
        return logs(tool, options)
    return monitor(tool, options, arguments)
